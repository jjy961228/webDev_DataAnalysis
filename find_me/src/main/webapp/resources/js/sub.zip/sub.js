$(function(){
    $(".btn--close").on("click", function(){
        $(this).parents(".popup_wrap").stop().fadeOut(300);
    });

    $(".popup--post__close").on("click", function(){
        $(".popup--post").stop().fadeOut(300);
    });

    $(".stuff-list>li>a").on("click", function(){
        $(".popup--post").stop().fadeIn(300);
        return false;
    });

    let heartFlag = false;
    $(".ul--auction > li > button").on("click", function(){
        if(heartFlag === false) {
            $(this).children("span").text("♥");
            heartFlag = true;
        } else {
            $(this).children("span").text("♡");
            heartFlag = false;
        }
    });

    $(".sub__nav--depth3 li").on("click", function(){
        $(".sub__nav--depth3 li").not(this).removeClass("active");
        $(this).addClass("active");

        let tableOrder = $(this).index() + 1;
        $(".mileage__table").removeClass("active");
        $(".mileage__table:nth-of-type(" + tableOrder + ")").addClass("active");
    });

});